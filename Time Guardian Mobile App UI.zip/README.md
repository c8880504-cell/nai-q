
  # Time Guardian Mobile App UI

  This is a code bundle for Time Guardian Mobile App UI. The original project is available at https://www.figma.com/design/qu71F6I96MH0WqG6xW1zVl/Time-Guardian-Mobile-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  